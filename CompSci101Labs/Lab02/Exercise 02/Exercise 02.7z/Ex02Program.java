public class Ex02Program {
    public void start() {
    }
}
