public class Ex02App {
    public static void main(String[] args) {
        Ex02Program p = new Ex02Program();
        p.start();
    }
}